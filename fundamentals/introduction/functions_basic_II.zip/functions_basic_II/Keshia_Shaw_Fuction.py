# # Countdown
# def countdown(n: int):
#     integers = []
#     print([n])
#     if n >= 1:
#         countdown (n - 1)
#     return integers
# countdown(6)

# Print and Return
mylist = [10,20]
def my_fxn():
    print(mylist[0])
    return(mylist[1])

print(my_fxn())

# # First Plus Lenght
# def sum(numb):
#     total = 0
#     for x in numb:
#         total +=x
#         return total
#     # numb(4,5,6)


# # Values Greater than Second
# def my_function(old):
#     return [x for x in old if x>10]
# print(my_function([1,2,3,4,5]))

# # This Lenght, That Value
# def two_int():
#     arry = list(range(start, start + length))
#     print(arry)